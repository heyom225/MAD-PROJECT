package com.example.madproject

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp


@Composable
fun HeadingTitle(title: String, subtitle: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 42.dp)
    ) {
        Column {
            Text(
                text = title, style = TextStyle(
                    color = Color(0xff009475),
                    fontSize = 24.sp,
                    fontWeight = FontWeight(700)
                )
            )
            Text(
                text = subtitle, style = TextStyle(
                    color = Color(0xff009475),
                    fontSize = 14.sp,
                    fontWeight = FontWeight(400),
                )
            )
        }
    }
}


@Composable
fun DragBar(

) {
    Box(
        modifier = Modifier
            .background(
                color = Color(0xffF0F0F0),
                shape = RoundedCornerShape(18.dp)
            )
            .height(390.dp)
            .width(36.dp)
            .padding(top = 70.dp)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    color = Color(0xff009475),
                    shape = RoundedCornerShape(18.dp)
                )
        ) {

        }
    }
}

@Composable
fun NextButton(
    name:String
) {
    Box(
        modifier = Modifier
            .height(54.dp)
            .width(306.dp)
            .background(
                color = PrimaryColor,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable {

            },
        contentAlignment = Alignment.Center


    ) {
        Text(
            text = name , style = TextStyle(
                fontSize = 16.sp,
                fontWeight = FontWeight(600),
                color = Color.White


            )
        )
    }
}

@Composable
fun BottomText() {
    Row(
        modifier = Modifier.padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .height(20.dp)
                .width(20.dp)
        ) {
            Icon(Icons.Rounded.Lock, contentDescription = "Localized description")
        }

        Text(
            "Your data is safe and secure with us.", style = TextStyle(
                fontSize = 12.sp,
                fontWeight = FontWeight(300),
                color = Color.Black

            )
        )
    }
}

val PrimaryColor = Color(0xff009475)
val ButtonBlue = Color(0xffff0000)