package com.example.madproject

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp


@Composable
fun Avatar() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(color = Color.White),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        HeadingTitle("Bhargav,", "Choose your avatar.")
        AvatarCircle()
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {

            NextButton("REGISTER")
            BottomText()
        }
    }
}

@Composable
fun AvatarCircle() {
    Box(
        modifier = Modifier.height(152.dp).width(152.dp).background(
            color = Color(
                0xffD9D9D9
            ),shape = RoundedCornerShape(200.dp)
        )
    ) {

    }
}